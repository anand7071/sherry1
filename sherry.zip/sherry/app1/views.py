from django.shortcuts import render
from app1.models import full_name

# Create your views here.
def home(request):
    if request.method=="POST":
        print("this is post")
        first_name = request.POST['firstname']
        last_name= request.POST['lastname']

        ins = full_name(first_name=first_name, last_name=last_name)
        ins.save()
        
        print("the data is save")

    return render(request, "home.html")

def sucs(requst):
    return render(requst, "sucs.html")
