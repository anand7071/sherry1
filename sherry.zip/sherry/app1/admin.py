from django.contrib import admin
from app1.models import full_name

# Register your models here.
admin.site.register(full_name)